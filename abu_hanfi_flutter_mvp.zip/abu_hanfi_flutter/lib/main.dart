import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const AbuHanfiApp());

class AbuHanfiApp extends StatelessWidget {
  const AbuHanfiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'مطعم أبو حنفي',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B4513)),
      scaffoldBackgroundColor: const Color(0xFFF8F5F0),
      fontFamily: 'Arial',
    ),
    home: const Directionality(textDirection: TextDirection.rtl, child: AppGate()),
  );
}

class AppGate extends StatefulWidget {
  const AppGate({super.key});
  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> {
  Map<String, dynamic>? data;
  String? currentUser;
  String? currentRole;
  bool loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('abu_hanfi_data');
    if (raw != null) {
      data = jsonDecode(raw);
    } else {
      data = {
        'employees': <Map<String, dynamic>>[],
        'tables': List.generate(20, (i) => {
          'number': i + 1, 'guests': 0, 'startedAt': null,
          'employee': null, 'bill': 0.0
        }),
        'history': <Map<String, dynamic>>[],
      };
    }
    setState(() => loading = false);
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('abu_hanfi_data', jsonEncode(data));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if ((data!['employees'] as List).isEmpty) {
      return SetupScreen(onCreate: (name, pin) async {
        data!['employees'].add({'name': name, 'pin': pin, 'role': 'admin'});
        await save();
        setState(() { currentUser = name; currentRole = 'admin'; });
      });
    }
    if (currentUser == null) {
      return LoginScreen(employees: List<Map<String,dynamic>>.from(data!['employees']),
        onLogin: (name, role) => setState(() { currentUser = name; currentRole = role; }));
    }
    return HomeScreen(
      data: data!, user: currentUser!, role: currentRole!,
      onSave: save,
      onLogout: () => setState(() { currentUser = null; currentRole = null; }),
    );
  }
}

class SetupScreen extends StatefulWidget {
  final Future<void> Function(String, String) onCreate;
  const SetupScreen({super.key, required this.onCreate});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}
class _SetupScreenState extends State<SetupScreen> {
  final name = TextEditingController();
  final pin = TextEditingController();
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24),
      child: Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(
        mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.restaurant, size: 54, color: Color(0xFF8B4513)),
          const SizedBox(height: 12),
          const Text('مطعم أبو حنفي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const Text('إنشاء حساب المدير لأول مرة'),
          const SizedBox(height: 20),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المدير', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: pin, keyboardType: TextInputType.number, obscureText: true,
            decoration: const InputDecoration(labelText: 'رمز الدخول (4 أرقام على الأقل)', border: OutlineInputBorder())),
          const SizedBox(height: 18),
          FilledButton(onPressed: () {
            if (name.text.trim().isNotEmpty && pin.text.length >= 4) {
              widget.onCreate(name.text.trim(), pin.text);
            }
          }, child: const Text('إنشاء حساب المدير')),
        ],
      )))),
    ),
  );
}

class LoginScreen extends StatefulWidget {
  final List<Map<String,dynamic>> employees;
  final void Function(String, String) onLogin;
  const LoginScreen({super.key, required this.employees, required this.onLogin});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  String? selected;
  final pin = TextEditingController();
  String error = '';
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Card(
      child: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('مطعم أبو حنفي', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(
          value: selected,
          decoration: const InputDecoration(labelText: 'اختر الموظف', border: OutlineInputBorder()),
          items: widget.employees.map((e) => DropdownMenuItem(value: e['name'] as String, child: Text(e['name']))).toList(),
          onChanged: (v) => setState(() => selected = v),
        ),
        const SizedBox(height: 12),
        TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'رمز الدخول', border: OutlineInputBorder())),
        if (error.isNotEmpty) Text(error, style: const TextStyle(color: Colors.red)),
        const SizedBox(height: 16),
        FilledButton(onPressed: () {
          final found = widget.employees.where((e) => e['name'] == selected && e['pin'] == pin.text).toList();
          if (found.isNotEmpty) widget.onLogin(found.first['name'], found.first['role']);
          else setState(() => error = 'الاسم أو رمز الدخول غير صحيح');
        }, child: const Text('دخول')),
      ])),
    ))),
  );
}

class HomeScreen extends StatefulWidget {
  final Map<String,dynamic> data;
  final String user, role;
  final Future<void> Function() onSave;
  final VoidCallback onLogout;
  const HomeScreen({super.key, required this.data, required this.user, required this.role, required this.onSave, required this.onLogout});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  List<Map<String,dynamic>> get tables => List<Map<String,dynamic>>.from(widget.data['tables']);
  List<Map<String,dynamic>> get history => List<Map<String,dynamic>>.from(widget.data['history']);
  double get todaySales {
    final now = DateTime.now();
    return history.where((h) {
      final d = DateTime.tryParse(h['endedAt'] ?? '');
      return d != null && d.year == now.year && d.month == now.month && d.day == now.day;
    }).fold<double>(0, (s, h) => s + (h['bill'] as num).toDouble());
  }
  int get activeGuests => tables.fold<int>(0, (s,t) => s + ((t['startedAt'] != null) ? (t['guests'] as int) : 0));
  int get occupied => tables.where((t) => t['startedAt'] != null).length;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(), _tablesPage(), _historyPage(),
      if (widget.role == 'admin') _employeesPage(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('مطعم أبو حنفي'), actions: [
        Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Center(child: Text(widget.user))),
        IconButton(onPressed: widget.onLogout, icon: const Icon(Icons.logout), tooltip: 'تسجيل الخروج'),
      ]),
      body: pages[tab.clamp(0, pages.length-1)],
      bottomNavigationBar: NavigationBar(selectedIndex: tab.clamp(0, pages.length-1), onDestinationSelected: (v) => setState(() => tab=v),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.dashboard), label: 'الرئيسية'),
          const NavigationDestination(icon: Icon(Icons.table_restaurant), label: 'الطاولات'),
          const NavigationDestination(icon: Icon(Icons.receipt_long), label: 'السجل'),
          if (widget.role == 'admin') const NavigationDestination(icon: Icon(Icons.people), label: 'الموظفون'),
        ]),
    );
  }

  Widget _dashboard() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('ملخص المطعم', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.55, crossAxisSpacing: 10, mainAxisSpacing: 10,
      children: [
        _stat('الطاولات المشغولة', '$occupied / 20', Icons.table_restaurant),
        _stat('الزبائن الموجودون', '$activeGuests', Icons.groups),
        _stat('مبيعات اليوم', '${todaySales.toStringAsFixed(2)} ج.م', Icons.payments),
        _stat('الجلسات المكتملة', '${history.length}', Icons.check_circle),
      ]),
    const SizedBox(height: 18),
    const Text('حالة الطاولات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    _tableGrid(compact: true),
  ]);
  Widget _stat(String label, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
    Icon(icon, color: const Color(0xFF8B4513)), Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
  ])));
  Widget _tablesPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('إدارة 20 طاولة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12), _tableGrid(compact: false),
  ]);
  Widget _tableGrid({required bool compact}) => GridView.builder(
    shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: compact ? 4 : 2, childAspectRatio: compact ? 0.95 : 1.35, crossAxisSpacing: 9, mainAxisSpacing: 9),
    itemCount: tables.length,
    itemBuilder: (context, i) {
      final t = tables[i]; final busy = t['startedAt'] != null;
      return InkWell(onTap: () => busy ? _finish(t) : _start(t), child: Card(
        color: busy ? const Color(0xFFFFE8E5) : const Color(0xFFE5F4E8),
        child: Padding(padding: const EdgeInsets.all(8), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.table_restaurant, size: compact ? 22 : 30, color: busy ? Colors.red : Colors.green),
          Text('طاولة ${t['number']}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: compact ? 12 : 17)),
          Text(busy ? 'مشغولة • ${t['guests']} أفراد' : 'فارغة', style: TextStyle(fontSize: compact ? 9 : 12)),
          if (busy && !compact) const Text('اضغط لإنهاء الجلسة', style: TextStyle(fontSize: 10)),
          if (!busy && !compact) const Text('اضغط لبدء جلسة', style: TextStyle(fontSize: 10)),
        ])),
      ));
    },
  );
  Future<void> _start(Map<String,dynamic> t) async {
    final guests = TextEditingController(text: '2');
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: Text('بدء جلسة - طاولة ${t['number']}'),
      content: TextField(controller: guests, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'عدد الزبائن')),
      actions: [TextButton(onPressed: () => Navigator.pop(context,false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(context,true), child: const Text('تسجيل الدخول'))],
    ));
    final n = int.tryParse(guests.text) ?? 0;
    if (ok == true && n > 0) {
      t['guests'] = n; t['startedAt'] = DateTime.now().toIso8601String();
      t['employee'] = widget.user; t['bill'] = 0.0;
      await widget.onSave();
    }
  }
  Future<void> _finish(Map<String,dynamic> t) async {
    final bill = TextEditingController();
    final start = DateTime.parse(t['startedAt']);
    final duration = DateTime.now().difference(start);
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: Text('إنهاء جلسة - طاولة ${t['number']}'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('عدد الزبائن: ${t['guests']}'),
        Text('مدة الجلوس: ${duration.inHours} ساعة و${duration.inMinutes % 60} دقيقة'),
        const SizedBox(height: 10),
        TextField(controller: bill, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'قيمة الفاتورة بالجنيه')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context,false), child: const Text('رجوع')),
        FilledButton(onPressed: () => Navigator.pop(context,true), child: const Text('إنهاء وحفظ'))],
    ));
    if (ok == true) {
      final end = DateTime.now();
      final amount = double.tryParse(bill.text) ?? 0;
      history.insert(0, {
        'table': t['number'], 'guests': t['guests'], 'employee': t['employee'],
        'startedAt': t['startedAt'], 'endedAt': end.toIso8601String(),
        'minutes': end.difference(start).inMinutes, 'bill': amount,
      });
      t['guests'] = 0; t['startedAt'] = null; t['employee'] = null; t['bill'] = 0.0;
      widget.data['history'] = history;
      await widget.onSave();
    }
  }
  Widget _historyPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('سجل الجلسات والفواتير', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    if (history.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('لا توجد جلسات مسجلة بعد'))),
    ...history.map((h) => Card(child: ListTile(
      leading: const Icon(Icons.receipt_long),
      title: Text('طاولة ${h['table']} • ${h['guests']} زبائن • ${(h['bill'] as num).toStringAsFixed(2)} ج.م'),
      subtitle: Text('الموظف: ${h['employee']} | المدة: ${h['minutes']} دقيقة'),
      trailing: Text((h['endedAt'] ?? '').toString().substring(0, 10), style: const TextStyle(fontSize: 10)),
    ))),
  ]);
  Widget _employeesPage() {
    final name = TextEditingController(); final pin = TextEditingController();
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('حسابات الموظفين', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const Text('المدير يستطيع إضافة حسابات للكاشير والموظفين.'),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الموظف')),
        TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رمز الدخول')),
        const SizedBox(height: 10),
        FilledButton(onPressed: () async {
          if (name.text.trim().isNotEmpty && pin.text.length >= 4) {
            (widget.data['employees'] as List).add({'name': name.text.trim(), 'pin': pin.text, 'role': 'staff'});
            await widget.onSave();
            name.clear(); pin.clear();
          }
        }, child: const Text('إضافة موظف')),
      ]))),
      ...List<Map<String,dynamic>>.from(widget.data['employees']).map((e) => Card(child: ListTile(
        leading: const Icon(Icons.person), title: Text(e['name']), subtitle: Text(e['role'] == 'admin' ? 'مدير' : 'موظف'),
      ))),
    ]);
  }
}
